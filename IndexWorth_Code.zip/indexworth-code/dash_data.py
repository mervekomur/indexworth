import json, numpy as np
from collections import defaultdict
from exp import *
from workload import idx_name
NAMES={"d1":"Sales-Uniform","d2":"Sales-Skewed","d3":"Hospital"}
BUD=[0.05,0.10,0.20,0.40,0.80]
out={"budgets":BUD,"dbs":{}}
for db in DBS:
    gt=GT[db]; tr,te=split(db,0)
    m=train_model([d for d in DBS if d!=db]); pr=predict_r(m,db)
    cands=[]
    for ci,c in enumerate(gt["cands"]):
        t,cols=c["cand"]
        per=defaultdict(lambda:{"ml":[],"meas":[],"opt":[]})
        for qs,mm in c["per_query"].items():
            qi=int(qs); tid=gt["pool"][qi][0]; b=gt["base"][qi]
            per[tid]["ml"].append(pr[(qi,ci)]); per[tid]["meas"].append(max(-1,(b["lat"]-mm["lat"])/b["lat"])); per[tid]["opt"].append(max(-1,(b["cost"]-mm["cost"])/b["cost"]))
        cands.append(dict(sql=f"CREATE INDEX {idx_name((t,tuple(cols)))} ON {t} ({', '.join(cols)});",name=f"{t}({', '.join(cols)})",
            size=c["size"]/1e6,pred_size=pred_size(db,ci)/1e6,build=c["build_s"],
            per={k:{a:round(float(np.mean(v)),3) for a,v in d.items()} for k,d in sorted(per.items(),key=lambda x:int(x[0][1:]))}))
    runs={}
    for bf in BUD:
        B=bf*db_bytes(db)
        for mth,fn in [("Rule-based",lambda:rec_rule(db,tr,B)),("Cost-based greedy",lambda:rec_cost(db,tr,B)),("ML (proposed)",lambda:rec_ml(db,m,tr,B)),("Oracle (measured)",lambda:rec_oracle(db,tr,B))]:
            cfg,rt=fn(); ev=eval_config(db,cfg)
            runs[f"{bf}|{mth}"]=dict(cfg=sorted(cfg),lat=[round(ev["lat"][i],2) for i in te],size=ev["size"]/1e6,build=ev["build_s"],rec=rt)
    out["dbs"][db]=dict(name=NAMES[db],db_mb=db_bytes(db)/1e6,tables={k:int(v["rows"]) for k,v in gt["tabs"].items()},
        test=[dict(t=gt["pool"][i][0],sql=gt["pool"][i][1],base=round(gt["base"][i]["lat"],2)) for i in te],
        cands=cands,runs=runs)
json.dump(out,open("dash_data.json","w"))
print(len(json.dumps(out))//1024,"KB")
for db in DBS:
    print(db, out["dbs"][db]["runs"]["0.2|ML (proposed)"]["cfg"], sum(out["dbs"][db]["runs"]["0.2|ML (proposed)"]["lat"]))
