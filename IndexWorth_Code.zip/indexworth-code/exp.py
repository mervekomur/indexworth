"""Main experiments: benefit estimation, index recommendation vs baselines,
budget sweep, ablation, workload shift, statistics."""
import json, os, random, time, math
from collections import defaultdict
import numpy as np
from scipy import stats
from sklearn.ensemble import GradientBoostingRegressor
from features import build_pairs, X, ALL, GROUPS, est_size
from workload import parse, idx_name
from pgrun import sql, explain, explain_analyze, plan_nodes

DBS = ["d1", "d2", "d3"]
SEEDS = [0, 1, 2, 3, 4]
GT = {db: json.load(open(f"gt_{db}.json")) for db in DBS}
PAIRS = {db: build_pairs(GT[db]) for db in DBS}
CACHE_F = "config_cache.json"
CACHE = json.load(open(CACHE_F)) if os.path.exists(CACHE_F) else {}


def cand_t(gt, ci):
    c = gt["cands"][ci]["cand"]
    return (c[0], tuple(c[1]))


def db_bytes(db):
    return sum(v["bytes"] for v in GT[db]["tabs"].values())


def split(db, seed):
    rng = random.Random(seed)
    by_t = defaultdict(list)
    for i, (tid, _) in enumerate(GT[db]["pool"]):
        by_t[tid].append(i)
    tr, te = [], []
    for tid, ids in sorted(by_t.items()):
        ids = ids[:]; rng.shuffle(ids); h = len(ids) // 2
        tr += ids[:h]; te += ids[h:]
    return sorted(tr), sorted(te)


# ---------------------------------------------------------------- models
def train_model(dbs, cols=ALL, seed=0, train_q=None):
    pairs = []
    for db in dbs:
        for p in PAIRS[db]:
            if train_q is None or p["qi"] in train_q.get(db, ()):
                pairs.append(p)
    m = GradientBoostingRegressor(n_estimators=300, max_depth=4, learning_rate=0.05,
                                  subsample=0.8, random_state=seed)
    m.fit(X(pairs, cols), np.array([p["r"] for p in pairs]))
    return m


def predict_r(model, db, cols=ALL):
    pairs = PAIRS[db]
    pred = model.predict(X(pairs, cols))
    return {(p["qi"], p["ci"]): float(v) for p, v in zip(pairs, pred)}


# ---------------------------------------------------------------- size model
from sklearn.linear_model import LinearRegression
_SIZE = {}


def _size_feats(gt, cand):
    t, cols = cand
    rows = gt["tabs"][t]["rows"]
    nd = gt["cols"][f"{t}.{cols[0]}"]["n_distinct"]
    return [math.log(est_size(gt, cand)), nd / rows, len(cols)]


def size_model(db):
    """Calibrates the analytical B-tree size estimate on the OTHER databases (no index built here)."""
    if db not in _SIZE:
        Xs, ys = [], []
        for d in DBS:
            if d == db:
                continue
            for c in GT[d]["cands"]:
                cand = (c["cand"][0], tuple(c["cand"][1]))
                Xs.append(_size_feats(GT[d], cand)); ys.append(math.log(max(c["size"], 8192)))
        _SIZE[db] = LinearRegression().fit(np.array(Xs), np.array(ys))
    return _SIZE[db]


def pred_size(db, ci):
    gt = GT[db]
    return float(math.exp(size_model(db).predict(np.array([_size_feats(gt, cand_t(gt, ci))]))[0]))


# ---------------------------------------------------------------- selection
def greedy(benefit, sizes, queries, budget, interaction=True, per_size=True, regression_aware=True):
    """benefit: dict (qi,ci)->benefit (ms or cost units; negative = predicted regression).
    Gain of adding index i = sum_q max(0, b(q,i) - cur(q))  [+ sum_q min(0, b(q,i)) if regression-aware]."""
    chosen, used = [], 0.0
    cur = defaultdict(float)
    cands = sorted({ci for (_, ci) in benefit})
    bq = defaultdict(dict)
    neg = defaultdict(float)
    for (qi, ci), v in benefit.items():
        if qi in queries and v > 0:
            bq[ci][qi] = v
        elif qi in queries and v < 0 and regression_aware:
            neg[ci] += v
    while True:
        best, best_s, best_g = None, 0.0, 0.0
        for ci in cands:
            if ci in chosen or used + sizes[ci] > budget:
                continue
            if interaction:
                g = sum(max(0.0, v - cur[qi]) for qi, v in bq[ci].items())
            else:
                g = sum(bq[ci].values())
            g += neg[ci]
            s = g / sizes[ci] if per_size else g
            if g > 0 and s > best_s:
                best, best_s, best_g = ci, s, g
        if best is None:
            break
        chosen.append(best); used += sizes[best]
        for qi, v in bq[best].items():
            cur[qi] = max(cur[qi], v)
    return chosen


def rec_ml(db, model, train_q, budget, cols=ALL, interaction=True, per_size=True, regression_aware=True):
    t0 = time.time()
    pr = predict_r(model, db, cols)
    gt = GT[db]
    ben = {(qi, ci): r * gt["base"][qi]["lat"] for (qi, ci), r in pr.items()}
    sizes = {ci: pred_size(db, ci) for ci in range(len(gt["cands"]))}
    sel = greedy(ben, sizes, set(train_q), budget, interaction, per_size, regression_aware)
    return sel, time.time() - t0


def rec_cost(db, train_q, budget):
    gt = GT[db]
    ben = {}
    for ci, c in enumerate(gt["cands"]):
        for qs, m in c["per_query"].items():
            ben[(int(qs), ci)] = gt["base"][int(qs)]["cost"] - m["cost"]
    sizes = {ci: c["size"] for ci, c in enumerate(gt["cands"])}
    sel = greedy(ben, sizes, set(train_q), budget)
    # tuning time: every candidate is materialised and every relevant training query re-planned
    tq = set(train_q)
    t = sum(c["build_s"] + c["explain_s"] * sum(1 for q in c["per_query"] if int(q) in tq) / max(len(c["per_query"]), 1)
            for c in gt["cands"])
    return sel, t


def rec_oracle(db, train_q, budget):
    gt = GT[db]
    ben = {}
    for ci, c in enumerate(gt["cands"]):
        for qs, m in c["per_query"].items():
            ben[(int(qs), ci)] = gt["base"][int(qs)]["lat"] - m["lat"]
    sizes = {ci: c["size"] for ci, c in enumerate(gt["cands"])}
    return greedy(ben, sizes, set(train_q), budget), None


def rec_rule(db, train_q, budget):
    """Frequency heuristic: single-column indexes on the most frequently filtered/joined columns."""
    t0 = time.time()
    gt = GT[db]
    freq = defaultdict(int)
    for qi in train_q:
        for t, c, role, _ in parse(gt["pool"][qi][1])["preds"]:
            if role in ("eq", "range", "join"):
                freq[(t, c)] += 1
    singles = {cand_t(gt, ci)[0:1] + (cand_t(gt, ci)[1][0],): ci for ci in range(len(gt["cands"])) if len(cand_t(gt, ci)[1]) == 1}
    order = sorted(freq, key=lambda k: (-freq[k], -gt["cols"][f"{k[0]}.{k[1]}"]["n_distinct"]))
    chosen, used = [], 0.0
    for k in order:
        ci = singles.get(k)
        if ci is None:
            continue
        s = pred_size(db, ci)
        if used + s <= budget:
            chosen.append(ci); used += s
    return chosen, time.time() - t0


# ---------------------------------------------------------------- evaluation
def drop_all(db):
    for n in sql(db, "SELECT indexname FROM pg_indexes WHERE indexname LIKE 'cand_%'").split():
        sql(db, f"DROP INDEX IF EXISTS {n}")


def eval_config(db, cis):
    """Materialise the configuration and measure every pool query (cached)."""
    key = db + ":" + ",".join(map(str, sorted(cis)))
    if key in CACHE:
        return CACHE[key]
    gt = GT[db]
    drop_all(db)
    names, build = [], 0.0
    for ci in sorted(cis):
        t, cols = cand_t(gt, ci)
        n = idx_name((t, cols)); names.append(n)
        t0 = time.time(); sql(db, f"CREATE INDEX {n} ON {t} ({', '.join(cols)})"); build += time.time() - t0
    size = sum(float(sql(db, f"SELECT pg_relation_size('{n}')")) for n in names)
    qs = [q for _, q in gt["pool"]]
    lat = [b["lat"] for b in gt["base"]]
    if names:
        plans = explain(db, qs)
        run = [i for i, pl in enumerate(plans) if any(nd.get("Index Name") in names for nd in plan_nodes(pl))]
        meas = explain_analyze(db, [qs[i] for i in run], reps=2)
        for i, m in zip(run, meas):
            lat[i] = m[0]
    drop_all(db)
    res = dict(lat=lat, size=size, build_s=build, n=len(names))
    CACHE[key] = res
    json.dump(CACHE, open(CACHE_F, "w"))
    return res


def total(lat, qids):
    return float(sum(lat[i] for i in qids))
