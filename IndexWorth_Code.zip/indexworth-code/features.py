"""Feature extraction for (query, candidate index) pairs and labels."""
import math
import numpy as np
from workload import parse

STRUCT = ["c1_eq", "c1_range", "c1_join", "c1_order", "c1_group", "has_c2", "c2_eq", "c2_range",
          "c2_order", "n_matched", "eq_then_range", "covering", "n_tables", "has_limit", "has_groupby",
          "order_limit"]
STATS = ["log_rows", "distinct_ratio", "abs_corr", "width", "log_sel_c1", "log_sel_c2", "log_sel_table",
         "log_outer_rows", "log_fanout", "log_eff_rows", "log_est_size"]
OPT = ["log_base_cost", "seq_on_table", "log_base_rows", "log_base_lat"]
ALL = STRUCT + STATS + OPT
GROUPS = {"STRUCT": STRUCT, "STATS": STATS, "OPT": OPT}


def lg(x):
    return math.log10(max(x, 1e-9))


def est_size(gt, cand):
    """B-tree size estimate (PostgreSQL >= 13 deduplicates duplicate keys)."""
    t, cols = cand
    rows = gt["tabs"][t]["rows"]
    w = sum(gt["cols"][f"{t}.{c}"]["width"] for c in cols)
    nd = 1.0
    for c in cols:
        nd *= max(gt["cols"][f"{t}.{c}"]["n_distinct"], 1)
    nd = min(nd, rows)
    entry = 12 + 8 * math.ceil(w / 8)
    return (nd * entry + (rows - nd) * 6) / 0.9 + 8192 * 3


def roles(p, t, c):
    return {r for (tt, cc, r, _) in p["preds"] if tt == t and cc == c}


def pair_features(gt, qi, cand):
    q = gt["pool"][qi][1]
    p = parse(q)
    t, cols = cand
    c1 = cols[0]
    c2 = cols[1] if len(cols) > 1 else None
    r1 = roles(p, t, c1)
    r2 = roles(p, t, c2) if c2 else set()
    rows = gt["tabs"][t]["rows"]
    st1 = gt["cols"][f"{t}.{c1}"]
    sel = gt["sel"].get(str(qi), {})
    s1 = sel.get(f"{t}.{c1}", 1.0)
    s2 = sel.get(f"{t}.{c2}", 1.0) if c2 else 1.0
    st = sel.get(f"{t}.*", 1.0)
    # join: rows coming from the other side of the join
    outer, fanout = rows, 1.0
    if "join" in r1:
        others = [tt for tt in p["tables"] if tt != t]
        if others:
            o = others[0]
            outer = sel.get(f"{o}.*", 1.0) * gt["tabs"][o]["rows"]
        fanout = rows / max(st1["n_distinct"], 1)
    if r1 & {"eq", "range"}:
        eff = s1 * (s2 if (c2 and "eq" in r1 and (r2 & {"eq", "range"})) else 1.0) * rows
    elif "join" in r1:
        eff = min(rows, outer * fanout)
    elif "order" in r1 and p["limit"]:
        eff = 50.0 / max(st, 1e-6)
        eff = min(eff, rows)
    else:
        eff = rows
    refs = set(p["refs"].get(t, []))
    b = gt["base"][qi]
    f = dict(
        c1_eq=int("eq" in r1), c1_range=int("range" in r1), c1_join=int("join" in r1),
        c1_order=int("order" in r1), c1_group=int("group" in r1), has_c2=int(c2 is not None),
        c2_eq=int("eq" in r2), c2_range=int("range" in r2), c2_order=int("order" in r2),
        n_matched=int(bool(r1 - {"group"})) + int(bool(r2 - {"group"})),
        eq_then_range=int("eq" in r1 and bool(r2 & {"range", "order"})),
        covering=int(refs <= set(cols)), n_tables=len(p["tables"]), has_limit=int(p["limit"]),
        has_groupby=int(p["groupby"]), order_limit=int("order" in r1 and p["limit"]),
        log_rows=lg(rows), distinct_ratio=st1["n_distinct"] / rows, abs_corr=abs(st1["corr"]),
        width=sum(gt["cols"][f"{t}.{c}"]["width"] for c in cols),
        log_sel_c1=lg(s1), log_sel_c2=lg(s2), log_sel_table=lg(st), log_outer_rows=lg(outer),
        log_fanout=lg(fanout), log_eff_rows=lg(eff), log_est_size=lg(est_size(gt, cand)),
        log_base_cost=lg(b["cost"]), seq_on_table=int(t in b["seq"]), log_base_rows=lg(b["rows"]),
        log_base_lat=lg(b["lat"]),
    )
    return f


def build_pairs(gt):
    """Rows: (qi, cand_index, features, r_actual, r_optimizer, benefit_ms, used)."""
    out = []
    for ci, c in enumerate(gt["cands"]):
        cand = (c["cand"][0], tuple(c["cand"][1]))
        for qs, m in c["per_query"].items():
            qi = int(qs)
            b = gt["base"][qi]
            r = (b["lat"] - m["lat"]) / b["lat"]
            ropt = (b["cost"] - m["cost"]) / b["cost"]
            out.append(dict(qi=qi, ci=ci, f=pair_features(gt, qi, cand), r=max(-1.0, min(1.0, r)),
                            ropt=max(-1.0, min(1.0, ropt)), ben=b["lat"] - m["lat"],
                            costben=b["cost"] - m["cost"], used=m["used"]))
    return out


def X(pairs, cols=ALL):
    return np.array([[p["f"][c] for c in cols] for p in pairs], dtype=float)
