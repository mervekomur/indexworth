import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

R = json.load(open("results.json"))
NAMES = {"d1": "Sales-Uniform", "d2": "Sales-Skewed", "d3": "Hospital"}
plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})
COL = {"No index": "#9AA5B1", "Rule-based": "#E0A458", "Cost-based greedy": "#5B8DB8",
       "ML (proposed)": "#C0392B", "Oracle (measured)": "#4D4D4D"}
W = 3.35

# ---------------- Fig 1 architecture
fig, ax = plt.subplots(figsize=(W, 2.55))
ax.set_xlim(0, 10); ax.set_ylim(0, 7.6); ax.axis("off")
boxes = [
    (0.2, 6.0, 4.5, 1.2, "Workload log\n(SQL + observed latency)", "#EEF2F7"),
    (5.3, 6.0, 4.5, 1.2, "Parser & candidate\ngeneration (1- and 2-col)", "#EEF2F7"),
    (5.3, 4.1, 4.5, 1.3, "Feature extraction\n(pg_stats, EXPLAIN, structure)", "#EEF2F7"),
    (0.2, 4.1, 4.5, 1.3, "Learned benefit model\n(GBRT) + size model", "#FBE9E7"),
    (0.2, 2.1, 4.5, 1.3, "Regression-aware,\nbudgeted greedy selection", "#FBE9E7"),
    (5.3, 2.1, 4.5, 1.3, "CREATE INDEX on\nPostgreSQL 16", "#EEF2F7"),
    (2.6, 0.2, 4.8, 1.1, "Re-tune when the\nworkload window shifts", "#F4F4F4"),
]
for x, y, w, h, t, c in boxes:
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.15", fc=c, ec="#333", lw=0.6))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=6.8)
arr = dict(arrowstyle="-|>", lw=0.7, color="#333", mutation_scale=7)
for (x1, y1, x2, y2) in [(4.75, 6.6, 5.25, 6.6), (7.55, 5.95, 7.55, 5.45), (5.25, 4.75, 4.75, 4.75),
                         (2.45, 4.05, 2.45, 3.45), (4.75, 2.75, 5.25, 2.75), (7.55, 2.05, 6.4, 1.35),
                         (3.6, 1.35, 2.45, 2.05)]:
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=arr)
fig.savefig("fig1_arch.png", bbox_inches="tight"); plt.close()

# ---------------- Fig 2 estimator scatter (all databases)
fig, axs = plt.subplots(1, 2, figsize=(W, 1.75), sharey=True)
y = np.concatenate([R["scatter"][d]["y"] for d in R["scatter"]])
for ax, key, title in [(axs[0], "opt", "Optimizer cost (what-if)"), (axs[1], "ml", "Learned model (cross-DB)")]:
    x = np.concatenate([R["scatter"][d][key] for d in R["scatter"]])
    ax.scatter(x, y, s=3, alpha=0.25, color="#5B8DB8" if key == "opt" else "#C0392B", lw=0)
    ax.plot([-1, 1], [-1, 1], ls="--", lw=0.6, color="#555")
    ax.set_xlim(-1.05, 1.05); ax.set_ylim(-1.05, 1.05); ax.set_title(title, fontsize=7.5)
    ax.set_xlabel("Estimated benefit $r$", fontsize=7)
axs[0].set_ylabel("Measured benefit $r$", fontsize=7)
fig.tight_layout(); fig.savefig("fig2_scatter.png", bbox_inches="tight"); plt.close()

# ---------------- Fig 3 main results
methods = ["No index", "Rule-based", "Cost-based greedy", "ML (proposed)", "Oracle (measured)"]
fig, ax = plt.subplots(figsize=(W, 1.9))
dbs = ["d1", "d2", "d3"]; bw = 0.16
for k, m in enumerate(methods):
    means = [np.mean([r["total"] for r in R["main"][d][m]]) / 1000 for d in dbs]
    sds = [np.std([r["total"] for r in R["main"][d][m]]) / 1000 for d in dbs]
    ax.bar(np.arange(3) + (k - 2) * bw, means, bw, yerr=sds, color=COL[m], label=m, error_kw=dict(lw=0.5, capsize=1.2))
ax.set_xticks(range(3)); ax.set_xticklabels([NAMES[d] for d in dbs])
ax.set_ylabel("Test workload latency (s)")
ax.legend(fontsize=5.6, ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.22))
fig.savefig("fig3_main.png", bbox_inches="tight"); plt.close()

# ---------------- Fig 4 budget sweep
fig, axs = plt.subplots(1, 3, figsize=(W, 1.55), sharey=False)
for ax, d in zip(axs, dbs):
    for m in ["Rule-based", "Cost-based greedy", "ML (proposed)", "Oracle (measured)"]:
        bs = sorted(R["sweep"][d][m], key=float)
        ax.plot([float(b) * 100 for b in bs], [R["sweep"][d][m][b]["total"] / 1000 for b in bs], marker="o", ms=2, lw=0.8, color=COL[m], label=m)
    base = np.mean([r["total"] for r in R["main"][d]["No index"]][:1]) / 1000
    ax.axhline(base, ls=":", lw=0.6, color="#777")
    ax.set_xscale("log"); ax.minorticks_off(); ax.set_xticks([5, 10, 20, 40, 80]); ax.set_xticklabels(["5", "10", "20", "40", "80"], fontsize=6)
    ax.set_title(NAMES[d], fontsize=7); ax.tick_params(labelsize=6)
    ax.set_xlabel("Budget (% of DB)", fontsize=6.5)
axs[0].set_ylabel("Latency (s)", fontsize=6.5)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, fontsize=5.6, frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.08))
fig.tight_layout(w_pad=0.6); fig.savefig("fig4_budget.png", bbox_inches="tight"); plt.close()

# ---------------- Fig 5 feature importance
imp = R["importance"][:10][::-1]
fig, ax = plt.subplots(figsize=(W, 1.9))
ax.barh([k for k, _ in imp], [v for _, v in imp], color="#C0392B")
ax.set_xlabel("Gini importance (GBRT)"); ax.tick_params(labelsize=6.5)
fig.savefig("fig5_importance.png", bbox_inches="tight"); plt.close()

# ---------------- Fig 6 workload shift
fig, axs = plt.subplots(1, 2, figsize=(W, 1.6))
keys = ["No index", "Static (tuned on phase A)", "Adaptive cost-based (re-tuned)", "Adaptive ML (re-tuned on phase B)"]
lab = ["None", "Static", "Adapt.\ncost", "Adapt.\nML"]
cols = ["#9AA5B1", "#E0A458", "#5B8DB8", "#C0392B"]
for ax, d in zip(axs, ["d1", "d3"]):
    v = [np.mean(R["shift"][d][k]) / 1000 for k in keys]
    ax.bar(range(4), v, color=cols)
    ax.set_xticks(range(4)); ax.set_xticklabels(lab, fontsize=5.5); ax.set_title(NAMES[d], fontsize=7)
    ax.tick_params(labelsize=6)
axs[0].set_ylabel("Phase-B latency (s)", fontsize=6.5)
fig.tight_layout(); fig.savefig("fig6_shift.png", bbox_inches="tight"); plt.close()
print("figs ok")
