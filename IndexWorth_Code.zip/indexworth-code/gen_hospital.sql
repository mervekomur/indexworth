DROP TABLE IF EXISTS appointment, doctor, patient, specialty CASCADE;
SELECT setseed(0.17);
CREATE TABLE specialty AS
SELECT g AS specialty_id, 'Specialty '||g AS specialty_name, 1 + (g % 12) AS clinic_id
FROM generate_series(1, 40) g;
CREATE TABLE doctor AS
SELECT g AS doctor_id, md5(g::text) AS doctor_name,
       1 + floor(pow(random(), 2) * 40)::int AS specialty_id,
       1990 + floor(random()*35)::int AS start_year
FROM generate_series(1, 4000) g;
CREATE TABLE patient AS
SELECT g AS national_id, md5((g*3)::text) AS patient_name,
       1930 + floor(random()*95)::int AS birth_year,
       floor(pow(random(), 2) * 81)::int AS city_id,
       (random() < 0.5)::int AS gender
FROM generate_series(1, 500000) g;
CREATE TABLE appointment AS
SELECT g AS appointment_id,
       1 + floor(pow(random(), 1.5) * 500000)::int AS national_id,
       1 + floor(pow(random(), 2) * 4000)::int AS doctor_id,
       date '2021-01-01' + floor(pow(random(), 0.5) * 2000)::int AS appointment_date,
       floor(pow(random(), 2) * 400)::int AS diagnosis_code,
       (100 + floor(random()*900))::int AS fee,
       floor(pow(random(), 3) * 4)::int AS status
FROM generate_series(1, 3000000) g;
ALTER TABLE specialty ADD PRIMARY KEY (specialty_id);
ALTER TABLE doctor ADD PRIMARY KEY (doctor_id);
ALTER TABLE patient ADD PRIMARY KEY (national_id);
ALTER TABLE appointment ADD PRIMARY KEY (appointment_id);
VACUUM ANALYZE;
