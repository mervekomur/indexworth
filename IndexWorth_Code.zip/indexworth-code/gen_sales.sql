-- :skew = 1 (uniform) or 3 (power-law skew). Usage: psql -v skew=1
DROP TABLE IF EXISTS lineitem, orders, part, customer CASCADE;
SELECT setseed(0.42);
CREATE TABLE customer AS
SELECT g AS c_id,
       floor(pow(random(), :skew) * 25)::int AS c_nation,
       floor(pow(random(), :skew) * 5)::int  AS c_segment,
       round((random()*10000)::numeric, 2)   AS c_acctbal,
       md5(g::text) AS c_name
FROM generate_series(1, 100000) g;
CREATE TABLE part AS
SELECT g AS p_id,
       floor(pow(random(), :skew) * 25)::int  AS p_brand,
       floor(pow(random(), :skew) * 150)::int AS p_type,
       1 + floor(random() * 50)::int          AS p_size,
       round((random()*2000)::numeric, 2)     AS p_retail
FROM generate_series(1, 50000) g;
CREATE TABLE orders AS
SELECT g AS o_id,
       1 + floor(pow(random(), :skew) * 100000)::int AS o_cust,
       date '2020-01-01' + floor(pow(random(), 1.0/:skew) * 2190)::int AS o_date,
       floor(pow(random(), :skew) * 3)::int AS o_status,
       floor(pow(random(), :skew) * 5)::int AS o_priority,
       round((random()*50000)::numeric, 2) AS o_total,
       md5((g*7)::text) AS o_comment
FROM generate_series(1, 1000000) g;
CREATE TABLE lineitem AS
SELECT 1 + floor(random() * 1000000)::int AS l_order,
       1 + floor(pow(random(), :skew) * 50000)::int AS l_part,
       1 + floor(random() * 50)::int AS l_qty,
       round((random()*1000)::numeric, 2) AS l_price,
       floor(random() * 11)::int AS l_discount,
       date '2020-01-01' + floor(pow(random(), 1.0/:skew) * 2200)::int AS l_shipdate,
       floor(pow(random(), :skew) * 7)::int AS l_shipmode
FROM generate_series(1, 3000000) g;
ALTER TABLE customer ADD PRIMARY KEY (c_id);
ALTER TABLE part ADD PRIMARY KEY (p_id);
ALTER TABLE orders ADD PRIMARY KEY (o_id);
VACUUM ANALYZE;
