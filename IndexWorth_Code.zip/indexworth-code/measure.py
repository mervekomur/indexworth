"""Ground-truth collection: for every dataset, measure each query in the pool
without secondary indexes and with each candidate index alone; record planner
costs, index size and build time, plus statistics used as features."""
import json, sys, time
from workload import make_workload, candidates, parse, idx_name, DATASETS
from pgrun import sql, explain_analyze, explain, plan_nodes

N_PER_TEMPLATE = 16
POOL_SEED = 100


def drop_cands(db):
    names = sql(db, "SELECT indexname FROM pg_indexes WHERE indexname LIKE 'cand_%'").split()
    for n in names:
        sql(db, f"DROP INDEX IF EXISTS {n}")


def table_stats(db):
    rows = sql(db, "SELECT relname, reltuples::bigint, pg_relation_size(oid) FROM pg_class WHERE relkind='r' AND relnamespace='public'::regnamespace")
    tabs = {}
    for line in rows.splitlines():
        n, t, s = line.split("|"); tabs[n] = dict(rows=float(t), bytes=float(s))
    st = sql(db, "SELECT tablename, attname, n_distinct, correlation, avg_width, null_frac FROM pg_stats WHERE schemaname='public'")
    cols = {}
    for line in st.splitlines():
        t, a, nd, cor, w, nf = line.split("|")
        nd = float(nd); nd = -nd * tabs[t]["rows"] if nd < 0 else nd
        cols[f"{t}.{a}"] = dict(n_distinct=nd, corr=float(cor or 0), width=float(w), null_frac=float(nf))
    return tabs, cols


def main(db):
    t0 = time.time()
    drop_cands(db)
    pool = make_workload(db, N_PER_TEMPLATE, POOL_SEED)
    qs = [q for _, q in pool]
    C = candidates(db, pool)
    tabs, cols = table_stats(db)
    # planner info without indexes + selectivity probes
    base_plans = explain(db, qs)
    probes, keys = [], []
    for i, q in enumerate(qs):
        p = parse(q)
        for (t, c), preds in p["pred_txt"].items():
            keys.append((i, f"{t}.{c}")); probes.append(f"SELECT * FROM {t} WHERE " + " AND ".join(preds))
        for t in p["tables"]:
            allp = [x for (tt, cc), v in p["pred_txt"].items() if tt == t for x in v]
            if allp:
                keys.append((i, f"{t}.*")); probes.append(f"SELECT * FROM {t} WHERE " + " AND ".join(allp))
    probe_plans = explain(db, probes)
    sel = {}
    for (i, k), pl in zip(keys, probe_plans):
        t = k.split(".")[0]
        sel.setdefault(i, {})[k] = pl["Plan Rows"] / max(tabs[t]["rows"], 1)
    base = explain_analyze(db, qs, reps=3)
    print(db, "base done", round(time.time() - t0), flush=True)
    res = []
    for ci, c in enumerate(C):
        t, cs = c
        name = idx_name(c)
        tb = time.time()
        sql(db, f"CREATE INDEX {name} ON {t} ({', '.join(cs)})")
        build = time.time() - tb
        size = float(sql(db, f"SELECT pg_relation_size('{name}')"))
        rel = [i for i, q in enumerate(qs) if t in parse(q)["tables"]]
        te = time.time()
        plans = explain(db, [qs[i] for i in rel])
        explain_s = time.time() - te
        used = [any(n.get("Index Name") == name for n in plan_nodes(pl)) for pl in plans]
        run_ids = [i for i, u in zip(rel, used) if u]
        mm = dict(zip(run_ids, explain_analyze(db, [qs[i] for i in run_ids], reps=2)))
        # plan unchanged when the index is not used -> latency equals the no-index latency
        meas = [mm[i] if i in mm else (base[i][0], base[i][1]) for i in rel]
        res.append(dict(cand=[t, list(cs)], build_s=build, size=size, explain_s=explain_s,
                        per_query={str(i): dict(lat=m[0], plan_ms=m[1], cost=pl["Total Cost"], used=u)
                                   for i, m, pl, u in zip(rel, meas, plans, used)}))
        sql(db, f"DROP INDEX {name}")
        print(db, ci + 1, "/", len(C), name, round(build, 2), "s", int(size / 1e6), "MB", flush=True)
    base2 = explain_analyze(db, qs, reps=3)  # noise check
    out = dict(db=db, pool=pool, tabs=tabs, cols=cols, sel={str(k): v for k, v in sel.items()},
               base=[dict(lat=b[0], plan_ms=b[1], cost=p["Total Cost"], rows=p["Plan Rows"],
                          seq=[n["Relation Name"] for n in plan_nodes(p) if n["Node Type"] == "Seq Scan"])
                     for b, p in zip(base, base_plans)],
               base_repeat=[b[0] for b in base2], cands=res, total_s=time.time() - t0)
    json.dump(out, open(f"gt_{db}.json", "w"))
    print(db, "done", round(time.time() - t0), "s", flush=True)


if __name__ == "__main__":
    for db in sys.argv[1:]:
        main(db)
