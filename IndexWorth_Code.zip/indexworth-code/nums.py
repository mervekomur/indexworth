"""Derive every number used in the paper from results.json (and ground truth files)."""
import json
import numpy as np
from scipy import stats

R = json.load(open("results.json"))
DBS = ["d1", "d2", "d3"]
NAMES = {"d1": "Sales-Uniform", "d2": "Sales-Skewed", "d3": "Hospital"}
M = ["No index", "Rule-based", "Cost-based greedy", "ML (proposed)", "Oracle (measured)"]
N = {}

# main table per dataset
main_rows = []
for d in DBS:
    base = np.mean([r["total"] for r in R["main"][d]["No index"]])
    for m in M:
        rs = R["main"][d][m]
        tot = np.array([r["total"] for r in rs])
        main_rows.append(dict(db=NAMES[d], method=m, total=tot.mean() / 1000, sd=tot.std() / 1000,
                              p95=np.mean([r["p95"] for r in rs]), size=np.mean([r["size"] for r in rs]) / 1e6,
                              n=np.mean([r["n"] for r in rs]), build=np.mean([r["build"] for r in rs]),
                              rec=np.mean([r["rec"] or 0 for r in rs]), red=100 * (1 - tot.mean() / base),
                              qps=len(R["perq"][d][m]) / 5 / (tot.mean() / 1000)))
N["main_rows"] = main_rows

# statistics: two-sided Wilcoxon on 15 paired run totals + per-query, Holm correction
tests = []
for b in ["No index", "Rule-based", "Cost-based greedy", "Oracle (measured)"]:
    x = np.array([r["total"] for d in DBS for r in R["main"][d]["ML (proposed)"]])
    y = np.array([r["total"] for d in DBS for r in R["main"][d][b]])
    w = stats.wilcoxon(x, y, alternative="two-sided", zero_method="zsplit")
    qx = np.concatenate([R["perq"][d]["ML (proposed)"] for d in DBS]); qy = np.concatenate([R["perq"][d][b] for d in DBS])
    wq = stats.wilcoxon(qx, qy, alternative="two-sided", zero_method="zsplit")
    ratio = y / x
    rng = np.random.default_rng(0)
    boots = [np.exp(np.mean(np.log(rng.choice(ratio, len(ratio))))) for _ in range(10000)]
    per_db = {}
    for d in DBS:
        xd = np.array([r["total"] for r in R["main"][d]["ML (proposed)"]]); yd = np.array([r["total"] for r in R["main"][d][b]])
        per_db[d] = float(np.exp(np.mean(np.log(yd / xd))))
    # matched-pairs rank-biserial effect size on run totals
    diff = y - x
    rpos = stats.rankdata(np.abs(diff))
    rbc = (rpos[diff > 0].sum() - rpos[diff < 0].sum()) / rpos.sum()
    tests.append(dict(baseline=b, geo=float(np.exp(np.mean(np.log(ratio)))), lo=float(np.percentile(boots, 2.5)),
                      hi=float(np.percentile(boots, 97.5)), p_runs=float(w.pvalue), p_q=float(wq.pvalue),
                      wins=int((x < y).sum()), n=len(x), per_db=per_db, rbc=float(rbc)))
ps = sorted(range(len(tests)), key=lambda i: tests[i]["p_runs"])
k = len(tests); prev = 0
for rank, i in enumerate(ps):
    adj = min(1.0, max(prev, (k - rank) * tests[i]["p_runs"])); tests[i]["p_holm"] = adj; prev = adj
N["tests"] = tests

# estimation
N["est"] = R["estimation"]
N["noise"] = R["noise"]
N["importance"] = R["importance"]
N["ablation"] = {d: {k: float(np.mean(v)) / 1000 for k, v in R["ablation"][d].items()} for d in DBS}
N["shift"] = {d: {k: float(np.mean(v)) for k, v in R["shift"][d].items()} for d in R["shift"]}
N["sweep"] = R["sweep"]
json.dump(N, open("nums.json", "w"), indent=1)

for r in main_rows:
    print(f"{r['db']:14s} {r['method']:18s} {r['total']:7.2f}±{r['sd']:.2f}s red {r['red']:5.1f}% p95 {r['p95']:7.1f} size {r['size']:6.1f}MB n {r['n']:.1f} build {r['build']:.2f}s rec {r['rec']:.3f}s qps {r['qps']:.1f}")
for t in tests:
    print(t)
for d in DBS:
    for k, v in R["estimation"][d].items():
        print(d, k, {a: (round(b, 3) if isinstance(b, float) else b) for a, b in v.items()})
print(N["ablation"]); print(N["shift"])
