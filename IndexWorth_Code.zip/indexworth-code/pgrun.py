"""Thin PostgreSQL helpers (psql-based batch runner; no driver needed)."""
import json, subprocess, time, os, tempfile

PSQL = ["psql", "-h", "/tmp", "-U", "postgres", "-X", "-q", "-tA"]
SEP = "@@SEP@@"
TIMEOUT_MS = 4000


def sql(db, stmt):
    r = subprocess.run(PSQL + ["-d", db, "-c", stmt], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr)
    return r.stdout.strip()


def _batch(db, stmts, prefix=""):
    with tempfile.NamedTemporaryFile("w", suffix=".sql", delete=False) as f:
        f.write(prefix)
        for s in stmts:
            f.write(s.rstrip().rstrip(";") + ";\n")
            f.write(f"SELECT '{SEP}';\n")
        name = f.name
    r = subprocess.run(PSQL + ["-d", db, "-f", name], capture_output=True, text=True)
    os.unlink(name)
    parts = r.stdout.split(SEP)[: len(stmts)]
    return [p.strip() for p in parts]


def explain_analyze(db, queries, reps=2):
    """Return (exec_ms, plan_ms) per query; min over reps. Timeouts -> TIMEOUT_MS."""
    stmts = []
    for q in queries:
        for _ in range(reps):
            stmts.append("EXPLAIN (ANALYZE, TIMING OFF, FORMAT JSON) " + q)
    out = _batch(db, stmts, prefix=f"SET statement_timeout = {TIMEOUT_MS};\n")
    res = []
    for i in range(len(queries)):
        ex, pl = [], []
        for j in range(reps):
            txt = out[i * reps + j]
            if not txt:
                ex.append(float(TIMEOUT_MS)); pl.append(0.0); continue
            js = json.loads(txt)[0]
            ex.append(js["Execution Time"]); pl.append(js["Planning Time"])
        res.append((min(ex), min(pl)))
    return res


def explain(db, queries):
    """Planner-only EXPLAIN: returns plan JSON (root dict) per query."""
    out = _batch(db, ["EXPLAIN (FORMAT JSON) " + q for q in queries])
    return [json.loads(t)[0]["Plan"] for t in out]


def plan_nodes(plan):
    yield plan
    for c in plan.get("Plans", []):
        yield from plan_nodes(c)
