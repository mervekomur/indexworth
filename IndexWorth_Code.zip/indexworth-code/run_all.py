import json, time, sys
import numpy as np
from collections import defaultdict
from scipy import stats
from sklearn.metrics import f1_score, precision_score, recall_score, mean_absolute_error
import exp
from exp import (GT, PAIRS, DBS, SEEDS, split, train_model, predict_r, rec_ml, rec_cost, rec_oracle,
                 rec_rule, eval_config, total, db_bytes)
from features import ALL, GROUPS

R = {}
log = lambda *a: print(*a, flush=True)

# ------------------------------------------------ 0. measurement noise
noise = {}
for db in DBS:
    a = np.array([b["lat"] for b in GT[db]["base"]]); b = np.array(GT[db]["base_repeat"])
    noise[db] = dict(median_rel_diff=float(np.median(np.abs(a - b) / a)), p90_rel_diff=float(np.percentile(np.abs(a - b) / a, 90)),
                     n_queries=len(a), n_cands=len(GT[db]["cands"]), n_pairs=len(PAIRS[db]),
                     db_mb=exp.db_bytes(db) / 1e6, measure_min=GT[db]["total_s"] / 60,
                     all_cand_mb=sum(c["size"] for c in GT[db]["cands"]) / 1e6,
                     share_used=float(np.mean([p["used"] for p in PAIRS[db]])),
                     share_useful=float(np.mean([p["r"] > 0.1 for p in PAIRS[db]])),
                     share_regress=float(np.mean([p["r"] < -0.1 for p in PAIRS[db]])))
R["noise"] = noise
log("noise", noise)


# ------------------------------------------------ 1. benefit estimation accuracy
def est_metrics(y, yhat):
    y, yhat = np.array(y), np.array(yhat)
    rho = stats.spearmanr(y, yhat).correlation
    yb, pb = y > 0.1, yhat > 0.1
    reg, preg = y < -0.1, yhat < -0.1
    return dict(spearman=float(rho), mae=float(mean_absolute_error(y, yhat)),
                f1=float(f1_score(yb, pb)), precision=float(precision_score(yb, pb, zero_division=0)),
                recall=float(recall_score(yb, pb)),
                regress_recall=float(reg[preg].sum() / max(reg.sum(), 1)) if reg.sum() else None)


est = defaultdict(dict)
lodo_models = {}
for db in DBS:
    others = [d for d in DBS if d != db]
    m = train_model(others)
    lodo_models[db] = m
    pr = predict_r(m, db)
    y = [p["r"] for p in PAIRS[db]]
    est[db]["ML (cross-database)"] = est_metrics(y, [pr[(p["qi"], p["ci"])] for p in PAIRS[db]])
    est[db]["Optimizer cost (what-if)"] = est_metrics(y, [p["ropt"] for p in PAIRS[db]])
    # in-distribution: seed splits, train on training queries of all databases
    vals = defaultdict(list)
    for s in SEEDS:
        sp = {d: set(split(d, s)[0]) for d in DBS}
        mi = train_model(DBS, seed=s, train_q=sp)
        pri = predict_r(mi, db)
        te = [p for p in PAIRS[db] if p["qi"] not in sp[db]]
        for k, v in est_metrics([p["r"] for p in te], [pri[(p["qi"], p["ci"])] for p in te]).items():
            vals[k].append(v)
    est[db]["ML (in-distribution)"] = {k: float(np.mean([x for x in v if x is not None])) if any(x is not None for x in v) else None for k, v in vals.items()}
    # ablations (cross-database)
    for g, cols in GROUPS.items():
        keep = [c for c in ALL if c not in cols]
        ma = train_model(others, cols=keep)
        pa = predict_r(ma, db, cols=keep)
        est[db][f"ML w/o {g}"] = est_metrics(y, [pa[(p["qi"], p["ci"])] for p in PAIRS[db]])
    log("est", db, {k: round(v["spearman"], 3) for k, v in est[db].items()})
R["estimation"] = est
# feature importance (model trained on all data)
mall = train_model(DBS)
R["importance"] = sorted(zip(ALL, map(float, mall.feature_importances_)), key=lambda x: -x[1])
# scatter data for figure
R["scatter"] = {db: dict(y=[p["r"] for p in PAIRS[db]],
                         ml=[predict_r(lodo_models[db], db)[(p["qi"], p["ci"])] for p in PAIRS[db]],
                         opt=[p["ropt"] for p in PAIRS[db]]) for db in DBS}

# ------------------------------------------------ 2. recommendation vs baselines
BUDGET = 0.20
METHODS = ["Rule-based", "Cost-based greedy", "ML (proposed)", "Oracle (measured)"]


def recommend(method, db, tr, budget, s=0, model=None, **kw):
    if method == "Rule-based":
        return rec_rule(db, tr, budget)
    if method == "Cost-based greedy":
        return rec_cost(db, tr, budget)
    if method == "Oracle (measured)":
        return rec_oracle(db, tr, budget)
    return rec_ml(db, model or lodo_models[db], tr, budget, **kw)


main = defaultdict(lambda: defaultdict(list))
perq = defaultdict(lambda: defaultdict(list))
for db in DBS:
    B = BUDGET * db_bytes(db)
    base_lat = [b["lat"] for b in GT[db]["base"]]
    for s in SEEDS:
        tr, te = split(db, s)
        main[db]["No index"].append(dict(total=total(base_lat, te), p95=float(np.percentile([base_lat[i] for i in te], 95)),
                                         size=0, build=0, rec=0, n=0, cfg=[]))
        perq[db]["No index"] += [base_lat[i] for i in te]
        for mth in METHODS:
            cfg, rt = recommend(mth, db, tr, B, s)
            ev = eval_config(db, cfg)
            main[db][mth].append(dict(total=total(ev["lat"], te), p95=float(np.percentile([ev["lat"][i] for i in te], 95)),
                                      size=ev["size"], build=ev["build_s"], rec=rt, n=len(cfg), cfg=sorted(cfg)))
            perq[db][mth] += [ev["lat"][i] for i in te]
        log("main", db, s, {m: round(v[-1]["total"]) for m, v in main[db].items()})
R["main"] = {db: dict(v) for db, v in main.items()}
R["perq"] = {db: dict(v) for db, v in perq.items()}

# statistics: Wilcoxon on per-query latencies (paired), and on 15 (db, seed) totals
st = {}
for b in ["No index", "Rule-based", "Cost-based greedy"]:
    xs = [r["total"] for db in DBS for r in main[db]["ML (proposed)"]]
    ys = [r["total"] for db in DBS for r in main[db][b]]
    w = stats.wilcoxon(xs, ys, alternative="less", zero_method="zsplit")
    q_ml = np.concatenate([perq[db]["ML (proposed)"] for db in DBS]); q_b = np.concatenate([perq[db][b] for db in DBS])
    wq = stats.wilcoxon(q_ml, q_b, alternative="less", zero_method="zsplit")
    ratio = np.array(ys) / np.array(xs)
    rng = np.random.default_rng(0)
    boots = [np.exp(np.mean(np.log(rng.choice(ratio, len(ratio))))) for _ in range(5000)]
    st[b] = dict(n_runs=len(xs), p_runs=float(w.pvalue), n_queries=len(q_ml), p_queries=float(wq.pvalue),
                 geo_speedup=float(np.exp(np.mean(np.log(ratio)))), ci_low=float(np.percentile(boots, 2.5)),
                 ci_high=float(np.percentile(boots, 97.5)), wins=int(sum(np.array(xs) < np.array(ys))))
R["stats"] = st
log("stats", st)

# ------------------------------------------------ 3. budget sweep (seed 0)
sweep = defaultdict(lambda: defaultdict(dict))
for db in DBS:
    tr, te = split(db, 0)
    for bf in [0.05, 0.10, 0.20, 0.40, 0.80]:
        for mth in METHODS:
            cfg, _ = recommend(mth, db, tr, bf * db_bytes(db))
            ev = eval_config(db, cfg)
            sweep[db][mth][bf] = dict(total=total(ev["lat"], te), size=ev["size"])
    log("sweep", db)
R["sweep"] = {db: {m: v for m, v in d.items()} for db, d in sweep.items()}

# ------------------------------------------------ 4. ablation (end-to-end)
abl = defaultdict(lambda: defaultdict(list))
for db in DBS:
    B = BUDGET * db_bytes(db)
    others = [d for d in DBS if d != db]
    models = {g: (train_model(others, cols=[c for c in ALL if c not in cols]), [c for c in ALL if c not in cols]) for g, cols in GROUPS.items()}
    for s in SEEDS:
        tr, te = split(db, s)
        variants = {"Full model": dict(),
                    "w/o interaction-aware greedy": dict(interaction=False),
                    "w/o size-normalised gain": dict(per_size=False),
                    "w/o regression-aware penalty": dict(regression_aware=False)}
        for name, kw in variants.items():
            cfg, _ = rec_ml(db, lodo_models[db], tr, B, **kw)
            abl[db][name].append(total(eval_config(db, cfg)["lat"], te))
        for g, (mg, cols) in models.items():
            cfg, _ = rec_ml(db, mg, tr, B, cols=cols)
            abl[db][f"w/o {g} features"].append(total(eval_config(db, cfg)["lat"], te))
    log("abl", db, {k: round(np.mean(v)) for k, v in abl[db].items()})
R["ablation"] = {db: dict(v) for db, v in abl.items()}

# ------------------------------------------------ 5. workload shift
shift = {}
for db in ["d1", "d3"]:
    tids = sorted({t for t, _ in GT[db]["pool"]}, key=lambda x: int(x[1:]))
    A, Bt = set(tids[: len(tids) // 2]), set(tids[len(tids) // 2:])
    res = defaultdict(list)
    for s in SEEDS:
        tr, te = split(db, s)
        trA = [i for i in tr if GT[db]["pool"][i][0] in A]
        trB = [i for i in tr if GT[db]["pool"][i][0] in Bt]
        teB = [i for i in te if GT[db]["pool"][i][0] in Bt]
        Bb = BUDGET * db_bytes(db)
        base = [b["lat"] for b in GT[db]["base"]]
        res["No index"].append(total(base, teB))
        cfgA, _ = rec_ml(db, lodo_models[db], trA, Bb)
        res["Static (tuned on phase A)"].append(total(eval_config(db, cfgA)["lat"], teB))
        t0 = time.time(); cfgB, tB = rec_ml(db, lodo_models[db], trB, Bb)
        res["Adaptive ML (re-tuned on phase B)"].append(total(eval_config(db, cfgB)["lat"], teB))
        res["retune_s_ml"].append(tB)
        cfgC, tC = rec_cost(db, trB, Bb)
        res["Adaptive cost-based (re-tuned)"].append(total(eval_config(db, cfgC)["lat"], teB))
        res["retune_s_cost"].append(tC)
    shift[db] = dict(res)
    log("shift", db, {k: round(np.mean(v), 2) for k, v in res.items()})
R["shift"] = shift

json.dump(R, open("results.json", "w"))
log("ALL DONE")
