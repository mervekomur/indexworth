"""Query templates for the three datasets, a lightweight SQL predicate parser,
and candidate index generation."""
import random, re, datetime as dt
from collections import defaultdict

D0 = dt.date(2020, 1, 1)
H0 = dt.date(2021, 1, 1)


def d(base, k):
    return (base + dt.timedelta(days=int(k))).isoformat()


def sales_templates():
    R = random
    return {
        "S1": lambda: f"SELECT count(*), sum(orders.o_total) FROM orders WHERE orders.o_cust = {R.randint(1, 100000)}",
        "S2": lambda: (lambda s, k: f"SELECT orders.o_id, orders.o_total FROM orders WHERE orders.o_date BETWEEN '{d(D0, s)}' AND '{d(D0, s + k)}'")(R.randint(0, 2100), R.choice([1, 3, 7, 30, 90])),
        "S3": lambda: f"SELECT sum(lineitem.l_price) FROM lineitem WHERE lineitem.l_part = {R.randint(1, 50000)}",
        "S4": lambda: f"SELECT count(*) FROM lineitem WHERE lineitem.l_shipdate = '{d(D0, R.randint(0, 2190))}' AND lineitem.l_shipmode = {R.randint(0, 6)}",
        "S5": lambda: f"SELECT customer.c_name, sum(orders.o_total) FROM customer JOIN orders ON orders.o_cust = customer.c_id WHERE customer.c_nation = {R.randint(0, 24)} AND customer.c_segment = {R.randint(0, 4)} AND orders.o_status = {R.randint(0, 2)} GROUP BY customer.c_name",
        "S6": lambda: f"SELECT orders.o_id FROM orders WHERE orders.o_status = {R.randint(0, 2)} AND orders.o_priority = {R.randint(0, 4)} ORDER BY orders.o_date DESC LIMIT 20",
        "S7": lambda: f"SELECT sum(lineitem.l_qty) FROM lineitem JOIN part ON part.p_id = lineitem.l_part WHERE part.p_brand = {R.randint(0, 24)} AND part.p_type = {R.randint(0, 149)}",
        "S8": lambda: (lambda o, w: f"SELECT count(*) FROM lineitem WHERE lineitem.l_order BETWEEN {o} AND {o + w}")(R.randint(1, 990000), R.choice([10, 100, 1000, 5000])),
        "S9": lambda: f"SELECT avg(lineitem.l_discount) FROM lineitem WHERE lineitem.l_qty > {R.randint(1, 45)}",
        "S10": lambda: f"SELECT orders.o_id, orders.o_total FROM orders WHERE orders.o_total > {R.randint(0, 49000)} ORDER BY orders.o_total LIMIT 50",
        "S11": lambda: f"SELECT count(*) FROM orders WHERE orders.o_cust = {R.randint(1, 100000)} AND orders.o_date >= '{d(D0, R.randint(0, 2100))}'",
    }


def hospital_templates():
    R = random
    return {
        "H1": lambda: f"SELECT count(*) FROM appointment WHERE appointment.national_id = {R.randint(1, 500000)}",
        "H2": lambda: f"SELECT appointment.appointment_id, appointment.fee FROM appointment WHERE appointment.doctor_id = {R.randint(1, 4000)} AND appointment.appointment_date = '{d(H0, R.randint(0, 1999))}'",
        "H3": lambda: (lambda s, k: f"SELECT sum(appointment.fee) FROM appointment WHERE appointment.appointment_date BETWEEN '{d(H0, s)}' AND '{d(H0, s + k)}'")(R.randint(0, 1990), R.choice([1, 7, 30, 180])),
        "H4": lambda: f"SELECT patient.patient_name, appointment.appointment_date FROM patient JOIN appointment ON appointment.national_id = patient.national_id WHERE patient.city_id = {R.randint(0, 80)} AND patient.birth_year = {R.randint(1930, 2024)}",
        "H5": lambda: f"SELECT count(*) FROM appointment WHERE appointment.diagnosis_code = {R.randint(0, 399)} AND appointment.status = {R.randint(0, 3)}",
        "H6": lambda: f"SELECT doctor.doctor_name, count(*) FROM doctor JOIN appointment ON appointment.doctor_id = doctor.doctor_id WHERE doctor.specialty_id = {R.randint(1, 40)} AND appointment.appointment_date >= '{d(H0, R.randint(1500, 1999))}' GROUP BY doctor.doctor_name",
        "H7": lambda: f"SELECT appointment.appointment_id FROM appointment WHERE appointment.fee > {R.randint(100, 990)} ORDER BY appointment.fee DESC LIMIT 20",
        "H8": lambda: f"SELECT avg(appointment.fee) FROM appointment WHERE appointment.status = {R.randint(0, 3)}",
        "H9": lambda: (lambda y, k: f"SELECT count(*) FROM patient WHERE patient.birth_year BETWEEN {y} AND {y + k}")(R.randint(1930, 2020), R.choice([0, 2, 10])),
        "H10": lambda: f"SELECT appointment.appointment_id FROM appointment WHERE appointment.national_id = {R.randint(1, 500000)} ORDER BY appointment.appointment_date DESC LIMIT 5",
    }


DATASETS = {
    "d1": dict(name="Sales-Uniform", templates=sales_templates,
               pk={("customer", "c_id"), ("part", "p_id"), ("orders", "o_id")}),
    "d2": dict(name="Sales-Skewed", templates=sales_templates,
               pk={("customer", "c_id"), ("part", "p_id"), ("orders", "o_id")}),
    "d3": dict(name="Hospital", templates=hospital_templates,
               pk={("specialty", "specialty_id"), ("doctor", "doctor_id"), ("patient", "national_id"), ("appointment", "appointment_id")}),
}

COL = r"([a-z_]+)\.([a-z_]+)"


def parse(q):
    """Return dict: list of (table, col, role) and other syntactic facts."""
    preds = []
    where = re.split(r"\bWHERE\b", q, maxsplit=1)
    tail = where[1] if len(where) > 1 else ""
    tail = re.split(r"\bGROUP BY\b|\bORDER BY\b|\bLIMIT\b", tail)[0]
    for m in re.finditer(COL + r"\s*(=|>=|<=|>|<|BETWEEN)\s*([a-z_]+\.[a-z_]+)?", tail):
        t, c, op, rhs = m.group(1), m.group(2), m.group(3), m.group(4)
        if rhs:
            continue
        preds.append((t, c, "eq" if op == "=" else "range", m.group(0)))
    for m in re.finditer(r"\bON\s+" + COL + r"\s*=\s*" + COL, q):
        preds.append((m.group(1), m.group(2), "join", None))
        preds.append((m.group(3), m.group(4), "join", None))
    order = [(m.group(1), m.group(2), "order", None) for m in re.finditer(r"ORDER BY\s+" + COL, q)]
    group = [(m.group(1), m.group(2), "group", None) for m in re.finditer(r"GROUP BY\s+" + COL, q)]
    tables = sorted(set(re.findall(r"(?:FROM|JOIN)\s+([a-z_]+)", q)))
    refs = defaultdict(set)
    for t, c in re.findall(COL, q):
        refs[t].add(c)
    # full predicate text for each (table,col) in WHERE (for selectivity probes)
    pred_txt = defaultdict(list)
    for m in re.finditer(COL + r"\s*(=|>=|<=|>|<)\s*('[^']*'|[0-9.]+)", tail):
        pred_txt[(m.group(1), m.group(2))].append(m.group(0))
    for m in re.finditer(COL + r"\s+BETWEEN\s+('[^']*'|[0-9.]+)\s+AND\s+('[^']*'|[0-9.]+)", tail):
        pred_txt[(m.group(1), m.group(2))].append(m.group(0))
    return dict(preds=preds + order + group, tables=tables, refs={k: sorted(v) for k, v in refs.items()},
                limit="LIMIT" in q, groupby="GROUP BY" in q, pred_txt=dict(pred_txt))


def make_workload(db, n_per_template, seed):
    random.seed(seed)
    T = DATASETS[db]["templates"]()
    return [(tid, T[tid]()) for tid in T for _ in range(n_per_template)]


def candidates(db, queries):
    """Single-column indexes on every predicate/join/order column and two-column
    composites (equality column first) from co-occurring predicates."""
    pk = DATASETS[db]["pk"]
    cands = set()
    for _, q in queries:
        p = parse(q)
        per_t = defaultdict(list)
        for t, c, role, _ in p["preds"]:
            if role in ("eq", "range", "join", "order") and (t, c) not in pk:
                cands.add((t, (c,)))
            per_t[t].append((c, role))
        for t, lst in per_t.items():
            eqs = [c for c, r in lst if r == "eq"]
            others = [c for c, r in lst if r in ("eq", "range", "order")]
            for a in eqs:
                for b in others:
                    if a != b:
                        cands.add((t, (a, b)))
    return sorted(cands)


def idx_name(c):
    t, cols = c
    return "cand_" + t + "_" + "_".join(cols)
